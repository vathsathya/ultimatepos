# Changelog

All Notable changes to `laravel-paystack` will be documented in this file

## 2015-11-04
- Initial release

## 2020-05-23
- Support for Laravel 7
- Support for splitting payments into subaccounts
- Support for more than one currency. Now you can use USD!
- Support for multiple quantities
- Support for helpers