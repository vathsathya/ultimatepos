<?php

return [
    'paypal_transaction_declined'     => 'Nem lehet feldolgozni a fizetést, mivel a tranzakciódat elutasították a PayPal-on',
    'paypal_transaction_not_verified' => 'A tranzakciót nem lehet ellenőrizni a PayPal-ról',
    'paypal_connection_error'         => 'Nem lehet csatlakozni a PayPal-hoz. Kérjük, próbálja újra',
];
