<?php

return [
    'paypal_transaction_declined'     => 'Impossible de traiter le paiement car votre transaction a été refusée sur PayPal',
    'paypal_transaction_not_verified' => 'Impossible de vérifier la transaction depuis PayPal',
    'paypal_connection_error'         => 'Impossible de se connecter à PayPal. Veuillez réessayer',
];
