<?php

return [
    'paypal_transaction_declined'     => 'Unable To Process Payment As Your Transaction Was Declined On PayPal',
    'paypal_transaction_not_verified' => 'Unable To Verify Transaction From PayPal',
    'paypal_connection_error'         => 'Unable To Connect To PayPal. Please Try Again',
];
