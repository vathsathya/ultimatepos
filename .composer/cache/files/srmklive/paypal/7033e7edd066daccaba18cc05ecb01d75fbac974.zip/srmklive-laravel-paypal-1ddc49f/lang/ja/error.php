<?php

return [
    'paypal_transaction_declined'     => 'PayPalでお取引が拒否されたため、支払いを処理できません',
    'paypal_transaction_not_verified' => 'PayPalからの取引を確認できません',
    'paypal_connection_error'         => 'PayPalに接続できません。もう一度お試しください',
];
