<?php

namespace Spatie\Menu\Laravel;

use Illuminate\Support\Traits\Macroable;
use Spatie\Menu\Html as BaseHtml;

class Html extends BaseHtml
{
    use Macroable;
}
