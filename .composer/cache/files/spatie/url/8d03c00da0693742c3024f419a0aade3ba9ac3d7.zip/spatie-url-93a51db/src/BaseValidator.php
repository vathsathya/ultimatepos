<?php

namespace Spatie\Url;

use Spatie\Url\Contracts\Validator;

abstract class BaseValidator implements Validator
{
}
