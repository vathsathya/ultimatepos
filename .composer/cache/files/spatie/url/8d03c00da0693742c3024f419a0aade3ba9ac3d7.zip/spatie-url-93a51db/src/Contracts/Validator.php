<?php

namespace Spatie\Url\Contracts;

interface Validator
{
    public function validate(): void;
}
