---
title: About Us
---

[Spatie](https://spatie.be) is a webdesign agency based in Antwerp, Belgium.

Open source software is used in all projects we deliver. Laravel, Nginx, Ubuntu are just a few of the free pieces of software we use every single day. For this, we are very grateful. When we feel we have solved a problem in a way that can help other developers, we release our code as open source software [on GitHub](https://spatie.be/opensource).

This menu package was made by [Sebastian De Deyne](https://twitter.com/sebdedeyne). There are [many other contributors](https://github.com/spatie/laravel-menu/graphs/contributors) who devoted a bit of time and effort to make this package better.
