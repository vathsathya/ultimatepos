---
title: Requirements
weight: 3
---

The menu package requires **PHP 7.0 or higher**. The Laravel package also requires **Laravel 5.1 or higher**.
