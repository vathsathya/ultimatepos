---
title: Menus in your Laravel app
weight: 4
---
