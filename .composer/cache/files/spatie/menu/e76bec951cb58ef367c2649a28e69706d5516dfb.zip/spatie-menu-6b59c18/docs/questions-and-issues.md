---
title: Questions & Issues
weight: 5
---

Find yourself stuck using the package? Found a bug? Do you have general questions or suggestions for improving the menu package? Feel free to create an issue on the [menu](https://github.com/spatie/menu/issues) or [laravel-menu](https://github.com/spatie/laravel-menu/issues) repositories on GitHub, we'll try to address it as soon as possible.

If you've found a bug regarding security please mail [freek@spatie.be](mailto:freek@spatie.be) instead of using the issue tracker.
