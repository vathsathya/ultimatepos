---
title: v3
slogan: Html menu generator
githubUrl: https://github.com/spatie/menu
branch: main
---
