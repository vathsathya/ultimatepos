---
title: Changelog
weight: 6
---

All notable changes to `menu` and `laravel-menu` are documented in their changelogs on GitHub:

- [menu changelog](https://github.com/spatie/menu/blob/master/CHANGELOG.md) 
- [laravel-menu changelog](https://github.com/spatie/laravel-menu/blob/master/CHANGELOG.md) 