<?php

declare(strict_types=1);

namespace Arcanedev\LogViewer\Exceptions;

/**
 * Class     LogViewerException
 *
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 */
class LogViewerException extends \Exception {}
