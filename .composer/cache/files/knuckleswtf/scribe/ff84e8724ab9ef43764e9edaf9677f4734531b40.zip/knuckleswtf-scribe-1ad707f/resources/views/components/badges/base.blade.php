<small class="badge badge-{{ $colour }}">{{ $text }}</small>
