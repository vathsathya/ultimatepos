<?php

declare(strict_types=1);

namespace ZipStream;

/**
 * @api
 */
abstract class Exception extends \Exception {}
