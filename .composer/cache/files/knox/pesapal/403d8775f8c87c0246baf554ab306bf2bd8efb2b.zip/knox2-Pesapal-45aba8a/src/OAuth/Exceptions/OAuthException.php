<?php
/**
 * Created by PhpStorm.
 * User: mxgel
 * Date: 11/14/16
 * Time: 2:23 AM
 */

namespace Knox\Pesapal\OAuth\Exceptions;


use Exception;

/**
 * Class OAuthException
 *
 * @package Knox\Pesapal\OAuth\Exceptions
 */
class OAuthException extends Exception
{
    // Pass
}