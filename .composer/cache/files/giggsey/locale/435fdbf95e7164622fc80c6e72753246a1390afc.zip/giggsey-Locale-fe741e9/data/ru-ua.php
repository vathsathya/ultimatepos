<?php

declare(strict_types=1);
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'AC' => 'О-в Вознесения',
    'AE' => 'Объединенные Арабские Эмираты',
    'CK' => 'О-ва Кука',
    'CX' => 'О-в Рождества',
    'NF' => 'О-в Норфолк',
    'TL' => 'Тимор-Лесте',
    'UM' => 'Малые Тихоокеанские Отдаленные Острова США',
];
