<?php

declare(strict_types=1);
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'AG' => 'Antigua and Barbuda',
    'BA' => 'Bosnia and Herzegovina',
    'BL' => 'St Barthélemy',
    'EA' => 'Ceuta and Melilla',
    'GS' => 'South Georgia and South Sandwich Islands',
    'KN' => 'St Kitts and Nevis',
    'LC' => 'St Lucia',
    'MF' => 'St Martin',
    'PM' => 'St Pierre and Miquelon',
    'SH' => 'St Helena',
    'SJ' => 'Svalbard and Jan Mayen',
    'ST' => 'São Tomé and Príncipe',
    'TC' => 'Turks and Caicos Islands',
    'TT' => 'Trinidad and Tobago',
    'UM' => 'US Outlying Islands',
    'VC' => 'St Vincent and the Grenadines',
    'VI' => 'US Virgin Islands',
    'WF' => 'Wallis and Futuna',
];
