<?php

declare(strict_types=1);
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'CG' => 'Kongo',
    'CV' => 'Kabo Verde',
    'CZ' => 'Češka Republika',
    'HK' => 'SAR Hongkong',
    'KN' => 'Sveti Kits i Nevis',
    'MO' => 'SAR Makao',
    'PM' => 'Sveti Pjer i Mikelon',
    'RE' => 'Reunion',
    'UM' => 'Manja udaljena ostrva SAD',
    'VC' => 'Sveti Vinsent i Grenadini',
];
