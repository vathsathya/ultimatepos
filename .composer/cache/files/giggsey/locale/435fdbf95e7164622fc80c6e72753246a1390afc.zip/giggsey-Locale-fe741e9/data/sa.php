<?php

declare(strict_types=1);
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'BR' => 'ब्राजील',
    'CN' => 'चीन:',
    'DE' => 'जर्मनीदेश:',
    'FR' => 'फ़्रांस:',
    'GB' => 'संयुक्त राष्ट्र:',
    'IN' => 'भारतः',
    'IT' => 'इटली:',
    'JP' => 'जापन:',
    'RU' => 'रष्यदेश:',
    'US' => 'संयुक्त राज्य:',
];
