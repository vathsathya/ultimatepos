# Laravel Legacy Factories

This package provides support for the previous generation of Laravel factories (<= 7.x) for Laravel 8.x+.
