# Security Policy

**PLEASE DON'T DISCLOSE SECURITY-RELATED ISSUES PUBLICLY, [SEE BELOW](#reporting-a-vulnerability).**

## Supported Versions

Version | Security Fixes Until
--- | ---
3.1	| -
3.0	| 31-12-2018
2.1	| 15-5-2018

## Reporting a Vulnerability

If you discover a security vulnerability within Laravel Excel, please send an email to Patrick Brouwers at patrick@spartner.nl. All security vulnerabilities will be promptly addressed.
