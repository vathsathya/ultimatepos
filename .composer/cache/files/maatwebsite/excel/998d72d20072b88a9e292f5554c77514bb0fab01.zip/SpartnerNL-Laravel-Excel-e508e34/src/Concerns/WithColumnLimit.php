<?php

namespace Maatwebsite\Excel\Concerns;

interface WithColumnLimit
{
    public function endColumn(): string;
}
